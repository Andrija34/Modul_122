# Testprotokoll: Automatisiertes Systemstatus-Skript

## Testumgebung
- Ubuntu 22.04 LTS (via VM)
- bash 5.1, msmtp 1.8.15, base64 vorhanden

## Tests durchgeführt
☑️ systeminfo.cfg geladen  
☑️ Dummy-Wetterdaten erzeugt  
☑️ CPU-Grenzwert überschritten (Testwert 99 %)  
☑️ ZIP-Datei erstellt  
☑️ Mail mit Anhang empfangen ✅

## Fazit
Alle Anforderungen funktional erfüllt.
