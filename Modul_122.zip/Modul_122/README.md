# Systemstatus-Überwachung & Mailversand

> Automatisiertes Bash-Projekt für M122