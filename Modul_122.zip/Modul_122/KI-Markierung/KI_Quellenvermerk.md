# KI-Quellenvermerk

Dieses Projekt wurde teilweise mit ChatGPT unterstützt.
